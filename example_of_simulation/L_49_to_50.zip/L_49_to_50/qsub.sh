#!/bin/sh
#PBS -l walltime=24:00:00
#PBS -N EQUIL
#PBS -q normal
#PBS -l nodes=1:ppn=20
#PBS -m bae
#PBS -M tug92190@temple.edu
#PBS -o EQUIL
#PBS
cd $PBS_O_WORKDIR
module load gromacs/5.1.4-plumed

gmx grompp -f ee_Si.mdp -c equil.gro -p topol1.top  -o equil_1.tpr -maxwarn 1
gmx mdrun -s equil_1.tpr -nt 24  -deffnm equil_1 -v -maxh 23.5
